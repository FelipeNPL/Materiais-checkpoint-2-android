package com.example.intents_motivation

enum class PhraseType(i: Int) {
    ALL(0),
    HAPPY(1),
    SUNNY(2)
}