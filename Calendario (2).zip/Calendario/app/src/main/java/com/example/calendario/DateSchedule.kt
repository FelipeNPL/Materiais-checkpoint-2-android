package com.example.calendario

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DateSchedule(
    var date: String,
    var schedule: String
) : Parcelable
