package com.example.calendario

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import com.example.calendario.databinding.ActivityDetailCalendarioBinding
import com.example.calendario.DateSchedule

class DetailCalendario : AppCompatActivity() {

    private lateinit var databind: ActivityDetailCalendarioBinding
    private lateinit var dataSchedule: DateSchedule


    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databind = ActivityDetailCalendarioBinding.inflate(layoutInflater)
        setTheme(Theme.currentTheme)
        setContentView(databind.root)
        val intent = intent
        val day = intent.getIntExtra("day",-1)
        val month = intent.getIntExtra("month",-1)
        val year = intent.getIntExtra("year",-1)

        databind.DateSelected.text = "** $day/$month/$year **"

        dataSchedule = DateSchedule("", "")
        dataSchedule.date = databind.DateSelected.text.toString()



        databind.buttonSave.setOnClickListener {
            if (databind.scheduleTxt.text.isEmpty()) {
                databind.scheduleTxt.error = "Add your schedule!"
            } else {
                dataSchedule.schedule = databind.scheduleTxt.text.toString()
                Intent().apply {
                    putExtra("DATA_SCHEDULE", dataSchedule)
                    setResult(RESULT_OK, this)
                }
                this.finish()
            }

        }


    }

    override fun onBackPressed() {
        if (databind.scheduleTxt.text.isEmpty()) {
            databind.scheduleTxt.error = "Add your schedule!"
        } else {
            dataSchedule.schedule = databind.scheduleTxt.text.toString()
            Intent().apply {
                putExtra("DATA_SCHEDULE", dataSchedule)
                setResult(RESULT_OK, this)
            }
            this.finish()
        }
    }
}