package com.example.calendario

import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.example.calendario.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var databind: ActivityMainBinding


    private val register = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: androidx.activity.result.ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let { data ->
                val scheduleExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    data.getParcelableExtra("DATA_SCHEDULE", DateSchedule::class.java)
                } else {
                    data.getParcelableExtra<DateSchedule>("DATA_SCHEDULE")
                }
                scheduleExtra?.let {
                    databind.calendarIcon.visibility = View.VISIBLE
                    databind.calendarMessage.visibility = View.VISIBLE
                    databind.calendarMessage.text = scheduleExtra.date +"\n"+ scheduleExtra.schedule
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databind = ActivityMainBinding.inflate(layoutInflater)
        setTheme(Theme.currentTheme)
        setContentView(databind.root)

        databind.calendarIcon.visibility = View.GONE
        databind.calendarMessage.visibility = View.GONE

        databind.themeButton.setOnClickListener {
            Theme.switchTheme()
            recreate()
        }

        databind.calendarView.setOnDateChangeListener{_, year, month, dayOfMonth ->
            val intent = Intent(this, DetailCalendario::class.java)
            intent.putExtra("day", dayOfMonth)
            intent.putExtra("month", month)
            intent.putExtra("year", year)
            register.launch(intent)
        }







    }
}