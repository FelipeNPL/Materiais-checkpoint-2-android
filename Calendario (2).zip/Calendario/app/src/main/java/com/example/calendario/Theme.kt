package com.example.calendario

object Theme {

    var currentTheme = R.style.Base_Theme_Calendario

    private val ACTUAL = R.style.Base_Theme_Calendario
    private val NEW = R.style.AlternateTheme_Calendario

    fun switchTheme() {
        Theme.currentTheme = when (Theme.currentTheme) {
            ACTUAL -> NEW
            NEW -> ACTUAL
            else ->  -1
        }
    }

}