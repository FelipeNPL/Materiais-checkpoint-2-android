package com.example.stringsthemas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.stringsthemas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

//    40:00 para identificação (id) dos textos, fazendo binds, sem precisar falar o que é
    lateinit var bind : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater) //42:00
        setContentView(R.layout.activity_main)

        //43:00 - 47:30 falamos que o txtSecond é o string salvo second_lyric
        bind.txtSecondLyric.text = getText(R.string.second_lyric)
    }
}